<?php
namespace CEB\Shortcodes\Application_Form;

/**
 * Composant de rendu HTML du formulaire de candidature
 */
class Render {

	/**
	 * Affiche le formulaire en utilisant un buffer de sortie
	 *
	 * @return string Le code HTML généré.
	 */
	public function display(): string {
		ob_start();
		$this->render_html();
		return (string) ob_get_clean();
	}

	/**
	 * Génère le code HTML du formulaire
	 *
	 * @return void
	 */
	private function render_html(): void {
		?>
		<div class="ceb-application-form-container">
			<?php if ( isset( $_GET['success'] ) && '1' === $_GET['success'] ) : ?>
				<div class="notice notice-success is-dismissible" style="background-color: #d4edda; color: #155724; padding: 15px; margin-bottom: 20px; border: 1px solid #c3e6cb; border-radius: 4px;">
					<p><strong>Candidature envoyée avec succès !</strong> Nous avons bien reçu vos informations.</p>
					<p><strong>Attention :</strong> Si le collège Briand de Lons-le-Saunier n'est pas votre collège de secteur, nous vous rappelons que vous devez effectuer une 'Demande de dérogation' auprès de la 'Direction des services départementaux de l'Éducation nationale (DSDEN) du Jura — Division élèves, familles et second degré' en appelant le 03 84 87 27 39.</p>
				</div>
			<?php endif; ?>

			<?php if ( isset( $_GET['ceb_error'] ) ) : ?>
				<div class="notice notice-error is-dismissible" style="background-color: #f8d7da; color: #721c24; padding: 15px; margin-bottom: 20px; border: 1px solid #f5c6cb; border-radius: 4px;">
					<?php if ( 'age' === $_GET['ceb_error'] ) : ?>
						<p><strong>Erreur :</strong> L'âge du candidat doit être compris entre 7 et 17 ans.</p>
					<?php elseif ( 'tel' === $_GET['ceb_error'] ) : ?>
						<p><strong>Erreur :</strong> Le numéro de téléphone du représentant légal est invalide. Il doit comporter 10 chiffres.</p>
					<?php else : ?>
						<p><strong>Erreur :</strong> Une erreur est survenue lors de la soumission de votre candidature. Veuillez vérifier vos informations.</p>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<form id="ceb-application-form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">

				<?php wp_nonce_field( 'ceb_submit_application', 'ceb_application_nonce' ); ?>
				<input type="hidden" name="action" value="ceb_submit_application">

				<!-- 1. Identité de l'élève -->
				<fieldset>
					<legend>1. Identité de l'élève</legend>

					<div class="form-row">
						<label for="ceb_eleve_nom">Nom <span class="required">*</span></label>
						<input type="text" id="ceb_eleve_nom" name="ceb_eleve_nom" required placeholder="NOM DE L'ÉLÈVE">
					</div>

					<div class="form-row">
						<label for="ceb_eleve_prenom">Prénom <span class="required">*</span></label>
						<input type="text" id="ceb_eleve_prenom" name="ceb_eleve_prenom" required placeholder="Prénom">
					</div>

					<div class="form-row">
						<label for="ceb_eleve_ddn">Date de naissance <span class="required">*</span></label>
						<?php
						$max_date = wp_date( 'Y-m-d', strtotime( '-7 years' ) );
						$min_date = wp_date( 'Y-m-d', strtotime( '-17 years' ) );
						?>
						<input type="date" id="ceb_eleve_ddn" name="ceb_eleve_ddn" min="<?php echo esc_attr( $min_date ); ?>" max="<?php echo esc_attr( $max_date ); ?>" required>
					</div>

					<div class="form-row">
						<label>Sexe <span class="required">*</span></label>
						<div class="radio-group">
							<label><input type="radio" name="ceb_eleve_sexe" value="Masculin" required> Masculin</label>
							<label><input type="radio" name="ceb_eleve_sexe" value="Féminin" required> Féminin</label>
						</div>
					</div>

					<div class="form-row">
						<label for="ceb_eleve_ecole">Établissement scolaire actuel <span class="required">*</span></label>
						<input type="text" id="ceb_eleve_ecole" name="ceb_eleve_ecole" required>
					</div>

					<div class="form-row">
						<label for="ceb_eleve_classe">Classe actuelle <span class="required">*</span></label>
						<select id="ceb_eleve_classe" name="ceb_eleve_classe" required>
							<option value="">Sélectionnez...</option>
							<option value="CM1">CM1</option>
							<option value="CM2">CM2</option>
							<option value="6ème">6ème</option>
							<option value="5ème">5ème</option>
							<option value="4ème">4ème</option>
							<option value="3ème">3ème</option>
						</select>
					</div>

					<div class="form-row">
						<label for="ceb_eleve_lv1">LV1 <span class="required">*</span></label>
						<select id="ceb_eleve_lv1" name="ceb_eleve_lv1" required>
							<option value="">Sélectionnez...</option>
							<option value="Anglais">Anglais</option>
							<option value="Allemand">Allemand</option>
						</select>
					</div>

					<div class="form-row">
						<label for="ceb_eleve_lv2">LV2 (Optionnel)</label>
						<select id="ceb_eleve_lv2" name="ceb_eleve_lv2">
							<option value="Aucune">Aucune</option>
							<option value="Anglais">Anglais</option>
							<option value="Allemand">Allemand</option>
							<option value="Italien">Italien</option>
							<option value="Espagnol">Espagnol</option>
							<option value="Autre">Autre</option>
						</select>
					</div>

					<div class="form-row">
						<label for="ceb_eleve_classe_cible">Classe ciblée à la rentrée <span class="required">*</span></label>
						<select id="ceb_eleve_classe_cible" name="ceb_eleve_classe_cible" required>
							<option value="">Sélectionnez...</option>
							<option value="6ème">6ème</option>
							<option value="5ème">5ème</option>
							<option value="4ème">4ème</option>
							<option value="3ème">3ème</option>
						</select>
					</div>
				</fieldset>

				<!-- 2. Représentant légal -->
				<fieldset>
					<legend>2. Représentant légal</legend>

					<div class="form-row">
						<label for="ceb_legal_nom">Nom <span class="required">*</span></label>
						<input type="text" id="ceb_legal_nom" name="ceb_legal_nom" required placeholder="NOM DU REPRÉSENTANT">
					</div>

					<div class="form-row">
						<label for="ceb_legal_prenom">Prénom <span class="required">*</span></label>
						<input type="text" id="ceb_legal_prenom" name="ceb_legal_prenom" required placeholder="Prénom">
					</div>

					<div class="form-row">
						<label>Lien de parenté <span class="required">*</span></label>
						<div class="radio-group">
							<label><input type="radio" name="ceb_legal_lien" value="Père" required> Père</label>
							<label><input type="radio" name="ceb_legal_lien" value="Mère" required> Mère</label>
							<label><input type="radio" name="ceb_legal_lien" value="Tuteur" required> Tuteur</label>
						</div>
					</div>

					<div class="form-row">
						<label for="ceb_legal_adresse">Adresse <span class="required">*</span></label>
						<input type="text" id="ceb_legal_adresse" name="ceb_legal_adresse" required>
					</div>

					<div class="form-row">
						<label for="ceb_legal_cplt">Complément d'adresse</label>
						<input type="text" id="ceb_legal_cplt" name="ceb_legal_cplt">
					</div>

					<div class="form-row">
						<label for="ceb_legal_cp">Code Postal <span class="required">*</span></label>
						<input type="text" id="ceb_legal_cp" name="ceb_legal_cp" required pattern="[0-9]{5}">
					</div>

					<div class="form-row">
						<label for="ceb_legal_ville">Ville <span class="required">*</span></label>
						<input type="text" id="ceb_legal_ville" name="ceb_legal_ville" required placeholder="VILLE">
					</div>

					<div class="form-row">
						<label for="ceb_legal_tel">Téléphone <span class="required">*</span></label>
						<input type="tel" id="ceb_legal_tel" name="ceb_legal_tel" required>
					</div>

					<div class="form-row">
						<label for="ceb_legal_email">Courriel <span class="required">*</span></label>
						<input type="email" id="ceb_legal_email" name="ceb_legal_email" required>
					</div>
				</fieldset>

				<!-- 2b. Second Représentant légal (Optionnel) -->
				<fieldset>
					<legend>Second Représentant Légal (Optionnel)</legend>

					<div class="form-row">
						<label for="ceb_legal2_nom">Nom</label>
						<input type="text" id="ceb_legal2_nom" name="ceb_legal2_nom" placeholder="NOM DU REPRÉSENTANT">
					</div>

					<div class="form-row">
						<label for="ceb_legal2_prenom">Prénom</label>
						<input type="text" id="ceb_legal2_prenom" name="ceb_legal2_prenom" placeholder="Prénom">
					</div>

					<div class="form-row">
						<label>Lien de parenté</label>
						<div class="radio-group">
							<label><input type="radio" name="ceb_legal2_lien" value="Père"> Père</label>
							<label><input type="radio" name="ceb_legal2_lien" value="Mère"> Mère</label>
							<label><input type="radio" name="ceb_legal2_lien" value="Tuteur"> Tuteur</label>
						</div>
					</div>

					<div class="form-row">
						<label for="ceb_legal2_adresse">Adresse</label>
						<input type="text" id="ceb_legal2_adresse" name="ceb_legal2_adresse">
					</div>

					<div class="form-row">
						<label for="ceb_legal2_cplt">Complément d'adresse</label>
						<input type="text" id="ceb_legal2_cplt" name="ceb_legal2_cplt">
					</div>

					<div class="form-row">
						<label for="ceb_legal2_cp">Code Postal</label>
						<input type="text" id="ceb_legal2_cp" name="ceb_legal2_cp" pattern="[0-9]{5}">
					</div>

					<div class="form-row">
						<label for="ceb_legal2_ville">Ville</label>
						<input type="text" id="ceb_legal2_ville" name="ceb_legal2_ville" placeholder="VILLE">
					</div>

					<div class="form-row">
						<label for="ceb_legal2_tel">Téléphone</label>
						<input type="tel" id="ceb_legal2_tel" name="ceb_legal2_tel">
					</div>

					<div class="form-row">
						<label for="ceb_legal2_email">Courriel</label>
						<input type="email" id="ceb_legal2_email" name="ceb_legal2_email">
					</div>
				</fieldset>

				<!-- 3. Parcours échiquéen -->
				<fieldset>
					<legend>3. Parcours échiquéen</legend>

					<div class="form-row">
						<label for="ceb_echecs_debut">Année de début des Échecs <span class="required">*</span></label>
						<input type="number" id="ceb_echecs_debut" name="ceb_echecs_debut" min="2000" max="<?php echo esc_attr( wp_date( 'Y' ) ); ?>" required>
					</div>

					<div class="form-row">
						<label for="ceb_echecs_club">Club actuel (Optionnel)</label>
						<input type="text" id="ceb_echecs_club" name="ceb_echecs_club" list="clubs-region">
						<datalist id="clubs-region">
							<option value="Echiquier Ledonien">
							<option value="Ecole d'echecs ledonienne">
							<option value="Le Cavalier Bayard">
							<option value="Tour Prends Garde! Besancon">
							<option value="Echiquier Bisontin">
							<option value="Roi Blanc Montbeliard">
							<option value="Le Pion Tissalien Echecs">
							<option value="BelfortEchecs - AEAU">
							<option value="Cercle d'Echecs de Valdoie">
							<option value="Louhans Chateaurenaud Echecs">
						</datalist>
					</div>

					<div class="form-row">
						<label for="ceb_echecs_niveau">Niveau <span class="required">*</span></label>
						<select id="ceb_echecs_niveau" name="ceb_echecs_niveau" required>
							<option value="">Sélectionnez...</option>
							<option value="Débutant">Débutant</option>
							<option value="Compétition départementale">Compétition départementale</option>
							<option value="Compétition régionale">Compétition régionale</option>
							<option value="Compétition nationale">Compétition nationale</option>
						</select>
					</div>

					<div class="form-row">
						<label for="ceb_echecs_competitions">Principales compétitions effectuées(Optionnel)</label>
						<?php
						wp_editor( '', 'ceb_echecs_competitions', [
							'media_buttons' => false,
							'textarea_name' => 'ceb_echecs_competitions',
							'textarea_rows' => 4,
							'quicktags'     => false,
							'teeny'         => true,
						] );
						?>
					</div>

					<div class="form-row">
						<label for="ceb_echecs_titres">Titres notables obtenus (Optionnel)</label>
						<?php
						wp_editor( '', 'ceb_echecs_titres', [
							'media_buttons' => false,
							'textarea_name' => 'ceb_echecs_titres',
							'textarea_rows' => 4,
							'quicktags'     => false,
							'teeny'         => true,
						] );
						?>
					</div>

					<!-- Motivation (Fichier ou Texte) -->
					<div class="form-row">
						<label>Lettre de motivation <span class="required">*</span></label>
						<div class="radio-group">
							<label><input type="radio" name="ceb_motivation_type" value="fichier" checked required> Joindre un fichier</label>
							<label><input type="radio" name="ceb_motivation_type" value="texte" required> Rédiger ici</label>
						</div>
					</div>

					<div class="form-row" id="ceb_motivation_fichier_wrap">
						<label for="ceb_motivation_fichier">Fichier de motivation (PDF, DOC, DOCX, ODT, RTF) <span class="required">*</span></label>
						<input type="file" id="ceb_motivation_fichier" name="ceb_motivation_fichier" accept=".pdf,.doc,.docx,.odt,.rtf" required>
					</div>

					<div class="form-row" id="ceb_motivation_texte_wrap" style="display:none;">
						<label for="ceb_motivation_texte">Texte de motivation <span class="required">*</span></label>
						<?php
						wp_editor( '', 'ceb_motivation_texte', [
							'media_buttons' => false,
							'textarea_name' => 'ceb_motivation_texte',
							'textarea_rows' => 8,
							'quicktags'     => false,
						] );
						?>
					</div>
				</fieldset>

				<button type="submit" class="button button-primary">Soumettre ma candidature</button>
			</form>
		</div>

		<?php
	}
}
